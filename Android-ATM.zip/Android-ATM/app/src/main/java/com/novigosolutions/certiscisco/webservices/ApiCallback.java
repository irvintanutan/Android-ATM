package com.novigosolutions.certiscisco.webservices;


/**
 * Created by dalveersinghdaiya on 19/10/16.
 */

public interface ApiCallback {

    void onResult(int result, String resultdata);
}
