package com.novigosolutions.certiscisco.interfaces;

/**
 * Created by dhanrajk on 21-06-17.
 */
public interface RecyclerViewClickListener
{

    void recyclerViewListClicked(int ATMOrderId);
}