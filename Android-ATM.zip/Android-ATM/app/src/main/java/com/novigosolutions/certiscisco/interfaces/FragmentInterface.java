package com.novigosolutions.certiscisco.interfaces;

/**
 * Created by dhanrajk on 05-07-17.
 */

public interface FragmentInterface {
    void fragmentBecameVisible();
}