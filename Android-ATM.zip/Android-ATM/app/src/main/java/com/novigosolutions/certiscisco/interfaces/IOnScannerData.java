package com.novigosolutions.certiscisco.interfaces;

public interface IOnScannerData {

    void onDataScanned(String scanData);

}
