package com.novigosolutions.certiscisco.utils;

/**
 * Created by niteshpurohit on 08/01/16.
 */
public class Constatnts {

    public static int coinenvelopeid = -5;

}
