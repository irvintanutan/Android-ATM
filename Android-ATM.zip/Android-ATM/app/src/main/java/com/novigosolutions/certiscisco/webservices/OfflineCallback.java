package com.novigosolutions.certiscisco.webservices;


/**
 * Created by dalveersinghdaiya on 19/10/16.
 */

public interface OfflineCallback {

    void onOfflineUpdated(int result, String resultdata);
}
